<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl6.css">
    <title>Odloty samolotów</title>
</head>
<body>
    <section class="baner1">
        <h2>Odloty z lotniska</h2>
    </section>
    <section class="baner2">
        <img src="zad6.png" alt="logotyp">
    </section>
    <section class="glowny">
        <h4>tabela odlotów</h4>
        <table>
            <tr>
            <th>lp.</th>
            <th>numer rejsu</th>
            <th>czas</th>
            <th>kierunek</th>
            <th>status</th>
            </tr>
            <?php
                $con = mysqli_connect('localhost','root','','egzamin');
                $query = "SELECT id, nr_rejsu, czas,kierunek,status_lotu FROM odloty ORDER BY czas DESC;";
                $result = mysqli_query($con, $query);
                while ($ans = mysqli_fetch_array($result)) {
                    echo "<tr>";
                    echo "<td> $ans[0] </td>";
                    echo "<td> $ans[1] </td>";
                    echo "<td> $ans[2] </td>";
                    echo "<td> $ans[3] </td>";
                    echo "<td> $ans[4] </td>";
                    echo "</tr>";
                }
                mysqli_close($con);
            ?>
        </table>
    </section>
    <section class="stopka1">
        <a href="zad6.png" target="_blank">Pobierz obraz</a>
    </section>
    <section class="stopka2">
        <?php
             if(!isset($_COOKIE['visit'])){
                 setcookie('visit', time(), time() + 3600);
                 echo '<p><em>Dzień dobry! Sprawdź regulamin naszej strony.</em></p>';
             }
             else {
                 echo '<p><strong>Miło nam, że nas znowu odwiedziłeś!</strong></p>';
             }
        ?>
    </section>
    <section class="stopka3">
        Autor:00000000000
    </section>

</body>
</html>