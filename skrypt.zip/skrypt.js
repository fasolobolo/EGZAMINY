function wyslij() {
    wiadomosc = document.getElementById("wyslij").value;

    section = document.createElement('section')

    section.classList.add('Jolanta')

    const chat = document.getElementById('chat')   

    wiadomosc_wpisz = document.createTextNode(wiadomosc);

    section.appendChild(wiadomosc_wpisz)

    img = document.createElement('img')
    img.src = "Jolka.jpg"

    section.appendChild(img)

    chat.appendChild(section)
    
}
function losowa_odpowiedz() {
    var lista = [
    "Świetnie!",
    "Kto gra główną rolę?",
    "Lubisz filmy Tego reżysera?",
    "Będę 10 minut wcześniej",
    "Może kupimy sobie popcorn?",
    "Ja wolę Colę",
    "Zaproszę jeszcze Grześka",
    "Tydzień temu też byłem w kinie na Diunie",
    "Ja funduję bilety"]


    indeks = Math.round(Math.random() * 9)
    indeks_wybrany = lista[indeks]
    
    section = document.createElement('section')
    section.classList.add('Krzysiek')

    const chat = document.getElementById('chat')

    indeks_wybrany_wpisz = document.createTextNode(indeks_wybrany)
    section.appendChild(indeks_wybrany_wpisz)

    img = document.createElement('img')
    img.src = "Krzysiek.jpg"
    section .appendChild(img)

    chat.appendChild(section)

}