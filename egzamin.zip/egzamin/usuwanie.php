<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<a href="menu.html">Powrót do menu</a> <br>
<body>
    <form method="post" action="usuwanie.php">       
        Podaj id
        <input type="number" name="a"> </br>
        <input type="submit" value="wyślij">
    </form>
<?php
   $id = @$_POST['a'];
   $con = mysqli_connect('localhost','root','','testing') or die("Bład połączenia");
   $query = "DELETE FROM testing1 WHERE ID = $id;";
   $result = mysqli_query($con,$query) or die("bład zapytania <br>");
    echo mysqli_affected_rows($con)." wierszy usunięto";
   mysqli_close($con);
?>  

</body>
</html>