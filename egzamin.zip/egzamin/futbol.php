<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rozgrywki futbolowe</title>
    <link rel="stylesheet" href="styl.css">
    
</head>
<body>
    <section class="baner">
    <h2>Światowe rozgrywki piłkarskie</h2>
    <img src="obraz1.jpg" alt="boisko">
    </section>
    <section class="mecze">
    <?php
    $con = mysqli_connect("localhost","root","","egzamin");
    $query = "SELECT zespol1, zespol2, wynik, data_rozgrywki FROM rozgrywka WHERE zespol1 = 'EVG' ";
    $result = mysqli_query($con, $query);
    while($ans = mysqli_fetch_array($result)) {
        echo "<section class ='blok'>";
        echo "<h3>$ans[0] - $ans[1]</h3>";
        echo "<h4>$ans[2]</h4>";
        echo "<p>w dniu: $ans[3]</p>";
        echo "</section>";
    }
    mysqli_close($con);
?>
    </section>
    <section class="blok-glowny">
    <h2>Reprezentacja Polski</h2>
    </section>
    <section class="blok-lewy">
    <p>Podaj pozycję zawodników (1-bramkarze, 2-obrońcy, 3-pomocnicy, 4-napastnicy)</p>
    <!-- formularz php -->
    <form action="futbol.php" method="POST">
    <input type="number" name="a">
    <input type="submit" value="Sprawdź">
    </form>
    <ul>
    <?php
    $dane_z_pola_edycyjnego = @$_POST['a'];
    if ($dane_z_pola_edycyjnego != "") {
        $con = mysqli_connect("localhost","root","","egzamin");
        $query = "SELECT imie,nazwisko FROM zawodnik WHERE pozycja_id=$dane_z_pola_edycyjnego";
        $result = mysqli_query($con,$query);
        while ($ans = mysqli_fetch_array($result)) {
            echo "<li> <p>$ans[0] $ans[1]</p> </li>";
        }
        mysqli_close($con);
    }

    ?>
       
    </ul>
   
    </section>
    <section class="blok-prawy">
    <img src="zad1.png" alt="piłkarz", class="pilkarz">
    <p>Autor: Pesel</p>
    </section>


</body>
</html>

