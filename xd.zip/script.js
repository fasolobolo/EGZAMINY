zdj = document.querySelectorAll(".images")

zdj.forEach(element => {
    element.style.transition += '1s';

    element.addEventListener('mouseover', function() {

        element.style.transform += 'rotate(360deg)';
    
    }) 

});
var e = document.getElementById("select");
var value = e.options[e.selectedIndex].value;
var text = e.options[e.selectedIndex].text;
console.log(value)