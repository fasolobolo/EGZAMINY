zdj = document.querySelectorAll(".images")

zdj.forEach(element => {
    element.style.transition += '1s';

    element.addEventListener('mouseover', function() {

        element.style.transform += 'rotate(360deg)';
    
    }) 

});


//zadanie 2
zdj.forEach(element=> {
    select = document.querySelector(".shape")
    select.addEventListener('change' ,function() {
    index = select.selectedIndex
    switch(index) {
        case 1:
            element.classList.add("kolko")
            element.classList.remove('kwadrat')
            element.classList.remove('trojkat')
            console.log('kolko')
            break;
        case 0:
            element.classList.add('kwadrat')  
            element.classList.remove('trojkat')  
            element.classList.remove('kolko')
            console.log('kwadrat')
            break;
        case 2:
            element.classList.add('trojkat')    
            element.classList.remove('kolko')
            element.classList.remove('kwadrat')
            console.log('trojkat')
            break;
        default:
            console.log("default")
            break;
    }
})
})

//3
zdj.forEach(element=> {
    filter = document.querySelector(".filter")
    filter.addEventListener('change' ,function() {
        indeks = filter.selectedIndex
        switch(indeks) {
            case 0:
                element.classList.remove('negative')
                element.classList.remove('blur')
                element.classList.remove('sepia')
                break;
            case 1:
                element.classList.add('negative')
                element.classList.remove('sepia')
                element.classList.remove('blur')
                console.log('negative')
                break;
            case 2:
                element.classList.add('sepia')    
                element.classList.remove('negative')
                element.classList.remove('blur')
                console.log('sepia')
                break;
            case 3:
                element.classList.add('blur')
                element.classList.remove('negative')
                element.classList.remove('sepia')  
                console.log('blur')  
                break;
            default:
                element.classList.remove('negative')
                element.classList.remove('blur')
                element.classList.remove('sepia')
                break;
        }
})
//4
    borderrange = document.getElementById("borderrange")
    bordercolor = document.getElementById("bordercolor")
    borderrange.addEventListener('change', function() {
        element.border =  `${borderrange.value}px`
    })
    bordercolor.addEventListener('input',function() {
        element.style.borderColor = `${bordercolor.value}`
    })
    borderstyle = document.querySelector('.borderstyle')
    borderstyle.addEventListener('change', function() {
        indekss = borderstyle.selectedIndex
        switch(indekss) {
            case 0:
                element.style.borderStyle = 'dotted'
                break;
            case 1:
                element.style.borderStyle = 'solid'
                break;
            case 2:
                element.style.borderStyle = 'dashed'
                break;
            default:
                break;
        }
    })
})

