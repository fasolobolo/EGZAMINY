<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl.css">
    
    <title>Zdjecia</title>
</head>
<body>
    <form action="zadanie.php">
    <select class="shape" selected="1">
        <option value="2" >Kwadrat</option>
        <option value="1">Kółko</option>
        <option value="3">Trójkąt</option>
    </select>
    <select class="filter" selected="1">
        <option value="1">Brak Filtrów</option>
        <option value="2" >Negative</option>
        <option value="3">sepia</option>
        <option value="4">blur</option>
    </select>
    Podaj wielkość obramowania
    <input type="range" min="0" max="50" id="borderrange">
    Podaj kolor obramowania
    <input type="text" id="bordercolor">
    <select class="borderstyle"selected="1">
        <option value="1">Dotted</option>
        <option value="2">Solid</option>
        <option value="3">Dashed</option>
    </select>

    </form>
    <?php
        $con = mysqli_connect('localhost','root','','galeria');
        $query = "SELECT * FROM items";
        $result = mysqli_query($con,$query);
        while ($ans = mysqli_fetch_array($result)) {
            echo "<img src='$ans[1].jpg' width='550px' height='300px' title='$ans[2]' class='images '/>";
        }
        mysqli_close($con)
    ?>
<script src="script.js"></script>
</body>
</html>