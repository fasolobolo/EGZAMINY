<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl.css">
    
    <title>Zdjecia</title>
</head>
<body>
    <form action="zadanie.php">
    <select class="select">
        <option value="1">Kółko</option>
        <option value="2" selected="selected">Kwadrat</option>
        <option value="3">Trójkąt</option>
    </select>
    <input type="submit">
    </form>
    <?php
        $con = mysqli_connect('localhost','root','','galeria');
        $query = "SELECT * FROM items";
        $result = mysqli_query($con,$query);
        $class = 1;
        while ($ans = mysqli_fetch_array($result)) {
            echo "<img src='$ans[1].jpg' width='550px' height='300px' title='$ans[2]' class='images img$class'/>";
            $class +=1;

        }
        mysqli_close($con)
    ?>
<script src="script.js"></script>
</body>
</html>