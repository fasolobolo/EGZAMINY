import random
from random import randint

lista = [2,1,17,35,58,21,513,53,65,90]

lista_len = len(lista)

postortowana_lista = []



licznik_prób=1


lista_do_sortowania = [2,1,17,35,58,21,513,53,65,90]






lista_do_sortowania.sort()



while lista_do_sortowania != postortowana_lista: 
   
   postortowana_lista.append(lista[random.randint(0, (lista_len-1))])

   
   if len(postortowana_lista) >= (lista_len) and lista_do_sortowania!=postortowana_lista:
       
       postortowana_lista = []
       
       print("Próba ",licznik_prób," Nieudana")
       
       licznik_prób +=1



print("Nieposortowana lista: ",lista)
print("Posortowana lista: ",postortowana_lista)
