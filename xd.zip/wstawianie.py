lista = [3,5,6,2,1]
lista_posortowana = [3,5,6,2,1,5,7] 
lista_posortowana.sort()

while lista != lista_posortowana: 
    x = 0
    lista_dowstawania = [3,5]
    

