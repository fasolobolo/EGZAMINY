﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace pr01
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void plus_Click(object sender, RoutedEventArgs e)
        {
            TextBox liczba1 = (TextBox)this.FindName("liczba1");
            TextBox liczba2 = (TextBox)this.FindName("liczba2");

            int liczba1Value = Int32.Parse(liczba1.Text);
            int liczba2Value = Int32.Parse(liczba2.Text);

            MessageBox.Show("Wynik to: " + (liczba1Value + liczba2Value));

        }

        private void minus_Click(object sender, RoutedEventArgs e)
        {
            TextBox liczba1 = (TextBox)this.FindName("liczba1");
            TextBox liczba2 = (TextBox)this.FindName("liczba2");

            int liczba1Value = Int32.Parse(liczba1.Text);
            int liczba2Value = Int32.Parse(liczba2.Text);

            MessageBox.Show("Wynik to: " + (liczba1Value - liczba2Value));

        }

        private void razy_Click(object sender, RoutedEventArgs e)
        {
            TextBox liczba1 = (TextBox)this.FindName("liczba1");
            TextBox liczba2 = (TextBox)this.FindName("liczba2");

            int liczba1Value = Int32.Parse(liczba1.Text);
            int liczba2Value = Int32.Parse(liczba2.Text);

            MessageBox.Show("Wynik to: " + (liczba1Value * liczba2Value));

        }

        private void podziel_Click(object sender, RoutedEventArgs e)
        {
            TextBox liczba1 = (TextBox)this.FindName("liczba1");
            TextBox liczba2 = (TextBox)this.FindName("liczba2");

            int liczba1Value = Int32.Parse(liczba1.Text);
            int liczba2Value = Int32.Parse(liczba2.Text);

            MessageBox.Show("Wynik to: " + (liczba1Value / liczba2Value));

        }

        private void Pierwiastek_Click(object sender, RoutedEventArgs e)
        {
            TextBox liczba1 = (TextBox)this.FindName("liczba1");
            TextBox liczba2 = (TextBox)this.FindName("liczba2");

            int liczba1Value = Int32.Parse(liczba1.Text);
            int liczba2Value = Int32.Parse(liczba2.Text);

            MessageBox.Show("Wynik to: " + (liczba1Value / liczba2Value));
        }

        private void Potega_Click(object sender, RoutedEventArgs e)
        {
            TextBox liczba1 = (TextBox)this.FindName("liczba1");
            TextBox liczba2 = (TextBox)this.FindName("liczba2");

            int liczba1Value = Int32.Parse(liczba1.Text);
            int liczba2Value = Int32.Parse(liczba2.Text);

            MessageBox.Show("Wynik to: " + (liczba1Value / liczba2Value));
        }
    }
}