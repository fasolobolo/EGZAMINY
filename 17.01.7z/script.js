form = document.getElementById('form')

form.addEventListener('click', function() {

    liczba_L = document.getElementById('number').value;

    liczba_B = "";

    while (liczba_L != 0) {

    liczba_B += parseFloat(liczba_L % 2);
    
    liczba_L = Math.floor(liczba_L/2);
    
    }
    if (liczba_L == 0) { 
        liczba_B = liczba_B.split('').reverse().join('')

        liczba_B = liczba_B.replace(/(\d{4})/g, '$1 ').replace(/(^\s+|\s+$)/,'')
        
        html = document.getElementById('tekst').innerHTML = liczba_B;
    }
})

 
