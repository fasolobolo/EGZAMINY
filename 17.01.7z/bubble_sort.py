lista = [6,7,4,5,8]
liczba_1 = 0
liczba_2 = 1

/