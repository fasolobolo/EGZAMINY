<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <form id="form" type="submit" action="xd.php">
        <label for="input"></label>
        <input type="number" id="number">
        <input type="submit" value="submit">
    </form>

    <?php 
        $liczba_L = @$_POST['number'];

        $liczba_B = ""; 
        while ($liczba_L != 0) {

        $liczba_B += $liczba_L % 2;

        $liczba_L = floor($liczba_L / 2);
        }
        if ($liczba_L == 0 ) {
            $liczba_B = strrev($liczba_B);
            echo $liczba_B;
        }
    ?>


</body>
</html>