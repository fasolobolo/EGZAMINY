import math
liczba_L = float(input("podaj liczbe "))

licznik = 0
liczba_B = ''
while (liczba_L != 0):
    licznik+=1
    liczba_B += str(liczba_L%2)
    liczba_L = math.floor(liczba_L/2)
    if (licznik % 4) == 0:
        liczba_B += " "
if liczba_L == 0:
 
    liczba_B = liczba_B[::-1]
    print(liczba_B)