<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="wstawianie.css">
</head>
<body>
    <a href="menu.html">Powrót do menu</a> <br>
    <form method="post" action="wstawianie.php">       
        Podaj imie
        <input type="text" name="a"> </br>
        Podaj nazwisko
        <input type="text" name="b"> </br>
        Podaj klase
        <input type="text" name="c"> </br>
        <input type="submit" value="wyślij">
    </form>
<?php
   $imie = @$_POST['a'];
   $nazwisko = @$_POST['b'];
   $klasa = @$_POST['c'];
   $con = mysqli_connect('localhost','root','','testing') or die("Bład piołaczenia");
   $query = "INSERT INTO testing1(ID,IMIE,NAZWISKO,KLASA) VALUES (NULL,'$imie','$nazwisko','$klasa');";
   $result = mysqli_query($con,$query) or die("bład zapytania");
    echo mysqli_affected_rows($con)." wierszy dodano";
   mysqli_close($con)
?> 
</body>
</html>