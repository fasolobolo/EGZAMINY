<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="menu.html">Powrót do menu</a> <br>
    <form method="post" action="updateowanie.php">       
        Podaj ID
        <input type="text" name="a"> </br>
        kol1
        <input type="text" name="b"> </br>
        kol2
        <input type="text" name="c"> </br>
        kol3
        <input type="text" name="d"> </br>
        <input type="submit" value="wyślij">
    </form>
<?php
   $id =   @$_POST['a'];
   $kol1 = @$_POST['b'];
   $kol2 = @$_POST['c'];
   $kol3 = @$_POST['d'];
   $con = mysqli_connect('localhost','root','','testing') or die("Bład połączenia");
   $query = "UPDATE testing1 SET IMIE = '$kol1', NAZWISKO = '$kol2', KLASA = '$kol3'  WHERE ID = '$id';";
   $result = mysqli_query($con,$query) or die("bład zapytania");
    echo mysqli_affected_rows($con)." wierszy zmieniono";
   mysqli_close($con)
?>  

</body>
</html>