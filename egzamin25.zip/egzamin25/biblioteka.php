<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bibliotek publiczna</title>
    <link rel="StyleSheet" href="style.css">
</head>
<body>
    <section class="lewy">
    <h3>Polecamy dzieła autorów</h3>
    <ol>
       
    <?php
        $con = mysqli_connect('localhost','root','','biblioteka');
        $query = "SELECT autorzy.imie, autorzy.nazwisko FROM autorzy ORDER BY autorzy.nazwisko ASC;";
        $result = mysqli_query($con,$query);
        while ($ans = mysqli_fetch_array($result)) {
            echo "<li>";
            echo $ans[0], " ", $ans[1], "<br>";
            echo "</li>";
        }
        mysqli_close($con);
    ?>
    
    </ol>


    </section>
    <form method="post" action="biblioteka.php">
        Podaj imie:
        <input type="text" name="a"> <br>
        Podaj nazwisko:
        <input type="text" name="b"> <br>
        Podaj kod:
        <input type="number" name="c"> <br>
        <input type="submit" value="Wyślij">
    </form>
    <section class="środkowy"></section>
    <section class="prawy_gorny"></section>
    <section class="prawy_dolny">
        <?php
        
        $imie = @$_POST['a'];
        $nazwisko = @$_POST['b'];
        $kod = @$_POST['c'];
        if ( isset($imie) and isset($nazwisko) and isset($symbol)) { 
        $con = mysqli_connect('localhost', 'root', '', 'biblioteka');
        $query = "INSERT INTO `czytelnicy`(`imie`, `nazwisko`, `kod`) VALUES ('$imie','$nazwisko','$kod')";
        $result = mysqli_query($con,$query);
        echo mysqli_affected_rows($con). " Czytelnik $imie $nazwisko został/a dodana/y do bazy danych";
        mysqli_close($con);
        }
        ?>


    </section>

</body>
</html>