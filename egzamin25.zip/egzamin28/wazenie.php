<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ważenie samochodów towarowych</title>
    <link rel="stylesheet" href="styl.css">
    
</head>
<body>
    <?php
    header("refresh: 10")
    ?>
    <section class="baner1"><h1>Ważenie pojazdów we Wrocławiu</h1></section>
    <section class="baner2"><img src="obraz1.jpg" alt="waga"></section>
    <section class="lewy">
        <h2>Lokalizacje Wag</h2>
        <ol>
          <?php
            $con = mysqli_connect('localhost','root','','wazenietirow');
            $query = "SELECT lokalizacje.ulica FROM lokalizacje;";
            $result = mysqli_query($con, $query);
            while ($ans = mysqli_fetch_array($result )) {
                echo "<li>";
                echo "ulica $ans[0]";
                echo "</li>";
            }
            mysqli_close($con);
          ?>  
        </ol>
        <h2>Kontakt</h2>
        <a href="mailto:wazenie@wroclaw.pl">napisz</a>
    </section>
    <section class="srodkowy">
        <h2>Alerty</h2>
        <table class="tabela">
        <tr>
            <th scope="col">rejestracja</th>
            <th scope="col">ulica</th>
            <th scope="col">waga</th>
            <th scope="col">dzień</th>
            <th scope="col">czas</th>
        </tr>
                <?php
                    $con = mysqli_connect('localhost','root','','wazenietirow');
                    $query = "SELECT wagi.rejestracja, lokalizacje.ulica, wagi.waga, wagi.dzien, wagi.czas FROM wagi INNER JOIN lokalizacje ON lokalizacje.id = wagi.lokalizacje_id WHERE wagi.waga > 5;" or die("Błąd zapytania");
                    $result = mysqli_query($con, $query);
                    while ($ans = mysqli_fetch_array($result)) {
                        echo "<tr>";
                        echo "<td>$ans[0]</td>";
                        echo "<td>$ans[1]</td>";
                        echo "<td>$ans[2]</td>";
                        echo "<td>$ans[3]</td>";
                        echo "<td>$ans[4]</td>";
                        echo "</tr>";
                    }
                    mysqli_close($con);
                ?>
        </table>
        <?php
            $con = mysqli_connect('localhost','root','','wazenietirow');
            $query = "INSERT INTO `wagi`(`lokalizacje_id`, `waga`, `rejestracja`, `dzien`, `czas`) VALUES ('5',FLOOR((RAND()*10)+1),'DW12345',CURRENT_DATE,CURRENT_TIME);";
            $result = mysqli_query($con, $query);
            @header("Refresh: 10; URL=wazenie.php");
            mysqli_close($con);
        ?>
    </section>
    <section class="prawy"> <img src="obraz2.jpg" alt="tir" class="tir"></section>
    <section class="stopki"><p>Strone wykonał:numerxd</p></section>
</body>
</html>

