
function klik() {
    liczba1 = parseInt(document.getElementById('liczba1').value)
    liczba2 = parseInt(document.getElementById('liczba2').value)
    document.getElementById('wypisanie').innerHTML = "Dodanie: "+ (liczba1+liczba2)+ "<br>"+
                                                     "Odejmowanie: "+ (liczba1-liczba2)+ "<br>"+
                                                     "Mnożenie: "+ (liczba1*liczba2)+ "<br>"+
                                                     "Dzielenie: "+ (liczba1/liczba2)+ "<br>"+
                                                     "Reszta z dzielenia: "+ (liczba1%liczba2)+ "<br>"+
                                                     "Zaokrąglenie mnożenia: "+ Math.round(liczba1*liczba2)+ "<br>"+
                                                     "Zaokrąglenie mnożenia w dół: "+ Math.floor(liczba1*liczba2)+ "<br>"                                                                                                                                                                                                                                                                                                                            
}


a=0
var opr = "" 
var poczatkowe_value = 0
var terazniejsze_value = 0
function klik_liczba(liczba) {    
    if (a == 0) {
    document.getElementById('calc').value = ''
    a = 1;
    }

    document.getElementById('calc').value += liczba

    document.getElementById('plus').disabled = ''
}
function plus() {
    poczatkowe_value = parseInt(document.getElementById('calc').value)
    document.getElementById('calc').value = ''
    opr = "+"
}

function minus() {
    poczatkowe_value = parseInt(document.getElementById('calc').value)
    document.getElementById('calc').value = ''
    opr = "-"
}
function mnozenie() {
    poczatkowe_value = parseInt(document.getElementById('calc').value)
    document.getElementById('calc').value = ''
    opr = "*"
}
function dzielenie() {
    poczatkowe_value = parseInt(document.getElementById('calc').value)
    document.getElementById('calc').value = ''
    opr = "/"
}




function wynik() {
    terazniejsze_value = parseInt(document.getElementById('calc').value)
    if (opr == "+") {
        document.getElementById('calc').value = (poczatkowe_value+terazniejsze_value)
        opr = ''
    }
    if (opr == '-') {
        document.getElementById('calc').value = (poczatkowe_value-terazniejsze_value)
        opr = ''
    }
    if (opr == '*') {
        document.getElementById('calc').value = (poczatkowe_value*terazniejsze_value)
        opr = ''

    }
    if (opr == '/') {
        document.getElementById('calc').value = (poczatkowe_value/terazniejsze_value)
        opr = ''
    }
    }